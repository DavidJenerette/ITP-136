﻿// Week 2 Assignment
Console.WriteLine("Hello");
Console.WriteLine("Who is being seen today?");
string PatientName = Console.ReadLine();
Console.WriteLine("Welcome: " + PatientName);